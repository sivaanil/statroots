<?php
return [
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
    'version' => '0.1-a',
    'languages' => [
        'en-US' => 'English',
    ],
    'languageRedirects' => [
        'en-US' => 'en',
    ],
];
