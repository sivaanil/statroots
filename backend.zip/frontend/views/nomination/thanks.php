<div class="inner-content">
    <img src="/frontend/web/images/thanks.png">
</div>